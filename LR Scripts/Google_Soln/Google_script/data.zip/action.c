Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("1P_JAR=2024-02-05-10; DOMAIN=apis.google.com");

	web_add_cookie("AEC=Ae3NU9M13V_k7vzAAUcbANY-L0RifF3pavu4Q6m-vEogMC8nPVovl_fjVnc; DOMAIN=apis.google.com");

	web_add_cookie("NID=511=ES5kPNUjTMrJj7P7HdR8gWrGAN5JW8TKY5XQVgV4o2qJTVQBSyzufAAaykdvTeM405ID69UacafzYGkaYH2YAeYmRIgC5_HRyXgCgyMqPIhmRutOk9_p0p9dL0eJ3CmWS1ZUnOx2qRMV4i681yl02mqAei74wmhA7VK34rLnbow; DOMAIN=apis.google.com");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.gstatic.com/og/_/ss/k=og.qtm.8RUPaHb7e5o.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTungzasoekTaLKrPFUaQFpakqDmnA", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://www.gstatic.com/og/_/js/k=og.qtm.en_US.ZEEp2pdSHOQ.2019.O/rt=j/m=qabr,q_d,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTvRRKYp7I5vTn-AtFvme6Qlo6hq9Q", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	web_add_cookie("1P_JAR=2024-02-05-10; DOMAIN=play.google.com");

	web_add_cookie("AEC=Ae3NU9M13V_k7vzAAUcbANY-L0RifF3pavu4Q6m-vEogMC8nPVovl_fjVnc; DOMAIN=play.google.com");

	web_add_cookie("NID=511=NujEkwCuZWipyXjEQmLfOFZk0lwLmxChZmFNkBLfA3pyPgLFlRPDLKT6lXSz0KUXzO8uUAVoPXubgvwQHLnMkb8U5oYRXnPU6ofnRe8x-sxVGOScnIJuf-QG38wDqV9SO_ezootfpIjM5rB9f6cBn2VeLvyzBMdYLkU-G_BTRZR-RaFsmqvx_-vE; DOMAIN=play.google.com");

	lr_think_time(4);

	web_custom_request("log", 
		"URL=https://play.google.com/log?format=json&hasfast=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.google.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=[[1,null,null,null,null,null,null,null,null,null,[null,null,null,null,\"en-IN\",null,null,null,[[[\"Not A(Brand\",\"99\"],[\"Google Chrome\",\"121\"],[\"Chromium\",\"121\"]],0,\"Windows\",\"10.0.0\",\"x86\",\"\",\"121.0.6167.140\"],[1,0,0,0,0]]],373,[[\"1707125126743\",null,null,null,null,null,null,\"[108,40400,538,1,\\\"602241693.0\\\",\\\"1rHAZZn9EIeng8UPwr6LwAs\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2336,null,0,0,null,\\\"og-b7b2984b-db54-4861-b605-5fe388d3d76b\\\",null,null,null,"
		"null,null,null,null,0,null,null,null,19037050,null,null,null,null,0,[1],1,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sl\\\",25],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[]\"],null,null,null,null,1],[\"1707125126750\",null,null,null,null,null,null,\"[107,40400,538,1,\\\"602241693.0\\\",\\\"1rHAZZn9EIeng8UPwr6LwAs\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2343,null,0,0,null,\\\""
		"og-b7b2984b-db54-4861-b605-5fe388d3d76b\\\",null,null,null,null,null,null,null,8,null,null,null,19037050,null,null,null,null,0,[2],2,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sl\\\",25],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[]\"],null,null,null,null,2]],\"1707125127744\",null,null,null,null,null,null,null,null,null,null,null,null,null,[[null,[null,null,null,null,null,null,null,null,null,null,null,null,"
		"122505695]],9]]", 
		EXTRARES, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlgZ1SJEvRn2_isOlZ5L7hfWkcnd-87VcUEcC7Rt_eE-UFwh4-u1N4j4wC&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfwK31jSJoDS3wX4ZH2v5k49PLfabZSu90SO1eas4kL7IzpqiVbtXHE2Q&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSt4Zvuqg17L8xiVfbOLSa2Ljl60znIOJHhMXuDqX70yrRBHrTowpAOX2w&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQc7aSvkglLYBXhrgHtoijLpCK_HKD_Zss9ro9w7fc&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://lh5.googleusercontent.com/p/AF1QipORjSliv1rRditQBc53zc97FH9h9Gm-56kJvMQH=w92-h92-n-k-no", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	web_add_cookie("1P_JAR=2024-02-05-10; DOMAIN=id.google.com");

	web_add_cookie("AEC=Ae3NU9M13V_k7vzAAUcbANY-L0RifF3pavu4Q6m-vEogMC8nPVovl_fjVnc; DOMAIN=id.google.com");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:hPmQwZRwnyeZkRhdeYKC8o5xE4PZbm6QgbaNRu1ZqHE&cup2hreq=ef0412260093a7842a6f7360569ba3069c40635a19bb46d03c6bb7628d425171", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\"{a3c6961b-52c4-485c-9da4-b5756ce202d8}\",\"rd\":6241},\"updatecheck\":{},\"version\":\""
		"1.0.2738.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"Chrome 106+\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{94c24bb2-d83f-4ed7-8815-ba7ad7c52f9d}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\""
		"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{c630b339-4116-4fda-8aff-96ad59a4bc15}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"9.49.1\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f/20ol/20or:\",\"cohortname\":\"Control\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.b9685d1e3054ce061c8c804b6e8983c6f62deb37d3882c2de2ef300666e91af3\"}]},\"ping\":{\"ping_freshness\":\"{cf35f34b-1afa-425e-9fbe-17168a245a21}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"20230916.567854667.14\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6132,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4a6508925b2ffec931c1e3931ddeb15ca41d820a8264cd5a962b526e9932bcdf\"}]},\"ping\""
		":{\"ping_freshness\":\"{7f0a41ed-ab99-4d25-a957-febc12f591cd}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"2024.1.2.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{29cba2cb-b45c-4054-880b-6c4e188ef6bd}\",\"rd\":6241},\"updatecheck"
		"\":{},\"version\":\"7\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{85fa0ec8-2dd5-45ec-b6fa-6eb66e8d1ee5}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB"
		"\",\"packages\":{\"package\":[{\"fp\":\"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\"ping_freshness\":\"{7315f0b8-23cc-457a-b032-72e119b5f6ea}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{0e7ae5c9-1ed3-40ec-b2ea-5a646a5c7659}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\""
		"ping_freshness\":\"{4e8e9535-bdde-46b0-90f0-fbaf371ab40f}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.887c873b6c3a26844482754c8534268fcd848b8c543b652626b4d4ec367f26fd\"}]},\"ping\":{\"ping_freshness\":\"{d9bb291f-b114-493e-bc30-71720aa1eac5}\",\"rd\":6241},\"updatecheck\":"
		"{},\"version\":\"3017\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.e8b88e82a353cd12ae29fa096dc3cd36720cd11ede1ee7991cd7816d79714bd5\"}]},\"ping\":{\"ping_freshness\":\"{5f9bd759-1bc8-4105-994a-ea276b1d076c}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"8525\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{5c4d8ce9-0e67-4bf6-bf19-b671d5983462}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\""
		"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cadbf9a5f27721576d77d35576f37ca01ac34d86bce73958bf71cde62af71b48\"}]},\"ping\":{\"ping_freshness\":\"{8594c012-46ee-45b9-8206-58a462dceba4}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"432\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6156,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.05efc37d7431bec0be1bbeed73a1835a3d3b14d4e5cc2c3f3a9ac9d05f0a423d\"}]},\"ping\":{\"ping_freshness\":\"{97a2c1fb-d12b-47ab-b4e6-6a08cbd29e70}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"2024.2.1.1\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:23ml@0.1\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\""
		"}]},\"ping\":{\"ping_freshness\":\"{d3755605-da83-4442-81ef-88cc3a57b5ad}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.aeedb246d19256a956fedaa89fb62423ae5bd8855a2a1f3189161cf045645a19\"}]},\"ping\":{\"ping_freshness\":\"{c1aebd32-0749-4bef-9ade-da2a28db5f50}\",\"rd\":6241},\"updatecheck\":{},\""
		"version\":\"1.3.36.141\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{8688610c-05ab-4a36-bde9-4ded507af384}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\""
		"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4a34c298e4cc402e64872b776b98cff11bdc2e89b168834851a449e30a300f7b\"}]},\"ping\":{\"ping_freshness\":\"{8e954786-0897-4a91-b226-93b33a6f905e}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"847\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\""
		":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{d20465dd-09ee-48ac-b2fc-cd2af2a4b535}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.48fecfa3c6f59eb6c34fdd5e8f19e0678699e2f27dc8ebfa7025c246d4575c68\"}]},\"ping\":{\"ping_freshness\":\"{26b76938-f417-4e26-8682-c377ecb61c6e}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"2024.1.17.0\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6132,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.738f6ed18eb59593934e529fa42f819ee99067eb187a687a24c2a940bae078d3\"}]},\""
		"ping\":{\"ping_freshness\":\"{588700f7-9c88-4a59-b643-7c6572f9a5b3}\",\"rd\":6241},\"updatecheck\":{},\"version\":\"2024.1.31.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.140\",\"protocol\":\"3.1\","
		"\"requestid\":\"{604dc0d0-6160-43ff-95d7-dd536c1f77fc}\",\"sessionid\":\"{06b4562b-89e2-40e2-8465-8a7f1d3c0082}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.372\"},\"updaterversion\":\"121.0.6167.140\"}}", 
		EXTRARES, 
		"Url=https://fonts.gstatic.com/s/googlesans/v14/4UaGrENHsxJlGDuGo1OIlL3Owp4.woff2", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/i/productlogos/googleg/v6/24px.svg", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/i/productlogos/youtube/v9/192px.svg", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASGQlL1An4iaKj4hIFDUqFnlIhoEC7x3ryJrM=?alt=proto", "Referer=", ENDITEM, 
		"Url=https://id.google.com/verify/ANsg4T5fK_5WuGLym8XC5yNdfQYpMo4IWWxtzvIICDwzemzkwyzb6OLpKlrl3TVEuzG__-FuHc0KZ23N8y2Bqehksp1arJXiVLp_NVGyX5QxjYtqg7bEfQ", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	lr_think_time(14);

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"event\":[{\"download_time_ms\":21029,\"downloaded\":2211,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"8529\",\"previousversion\":\"8525\",\"total\":2211,\"url\":\"http://edgedl.me.gvt1.com/edgedl/diffgen-puffin/"
		"hfnkpimlhhgieaddgfemjhofmfblmnib/1.bda4d85c5aed0b1f9273f8a7bd2a922e52bc884d684ff820edc096cdf1656eb4/1.e8b88e82a353cd12ae29fa096dc3cd36720cd11ede1ee7991cd7816d79714bd5/58613ba8474c1dee89106d8455d27262bbfe7a0e8014a4bccc971e1d84bcd9d2.puff\"},{\"diffresult\":1,\"eventresult\":1,\"eventtype\":3,\"nextfp\":\"1.bda4d85c5aed0b1f9273f8a7bd2a922e52bc884d684ff820edc096cdf1656eb4\",\"nextversion\":\"8529\",\"previousfp\":\"1.e8b88e82a353cd12ae29fa096dc3cd36720cd11ede1ee7991cd7816d79714bd5\",\""
		"previousversion\":\"8525\"}],\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.bda4d85c5aed0b1f9273f8a7bd2a922e52bc884d684ff820edc096cdf1656eb4\"}]},\"version\":\"8529\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\""
		"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.140\",\"protocol\":\"3.1\",\"requestid\":\"{c52f287e-66a4-4635-8ba8-c6e9e8169d11}\",\"sessionid\":\"{06b4562b-89e2-40e2-8465-8a7f1d3c0082}\",\"updaterversion\":\"121.0.6167.140\"}}", 
		LAST);

	return 0;
}