Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_custom_request("Telemetry.Request", 
		"URL=https://nw-umwatson.events.data.microsoft.com/Telemetry.Request", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"EncType=application/xml", 
		"BodyBinary=\\x8A\\x0E\\x00\\x00<?xml version=\"1.0\"?>\n<req ver=\"2\">\n <tlm>\n  <src>\n   <desc>\n    <mach>\n     <os>\n      <arg nm=\"vermaj\" val=\"10\"/>\n      <arg nm=\"vermin\" val=\"0\"/>\n      <arg nm=\"verbld\" val=\"19045\"/>\n      <arg nm=\"vercsdbld\" val=\"3324\"/>\n      <arg nm=\"verqfe\" val=\"3324\"/>\n      <arg nm=\"csdbld\" val=\"3324\"/>\n      <arg nm=\"versp\" val=\"0\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"lcid\" val=\"1033\"/>\n      <arg nm=\""
		"geoid\" val=\"113\"/>\n      <arg nm=\"sku\" val=\"48\"/>\n      <arg nm=\"domain\" val=\"0\"/>\n      <arg nm=\"portos\" val=\"0\"/>\n      <arg nm=\"ram\" val=\"12286\"/>\n      <arg nm=\"svolsz\" val=\"149\"/>\n      <arg nm=\"wimbt\" val=\"0\"/>\n      <arg nm=\"blddt\" val=\"191206\"/>\n      <arg nm=\"bldtm\" val=\"1406\"/>\n      <arg nm=\"bldbrch\" val=\"vb_release\"/>\n      <arg nm=\"os\" val=\"Windows\"/>\n      <arg nm=\"osver\" val=\"10.0.19041.3324.amd64fre.vb_release.191206-1406\"/"
		">\n      <arg nm=\"buildflightid\" val=\"\"/>\n      <arg nm=\"expid\" val=\"\"/>\n      <arg nm=\"edition\" val=\"Professional\"/>\n     </os>\n     <hw>\n      <arg nm=\"form\" val=\"1\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"deviceclass\" val=\"Windows.Desktop\"/>\n      <arg nm=\"sysmfg\" val=\"VMware, Inc.\"/>\n      <arg nm=\"syspro\" val=\"VMware7,1\"/>\n      <arg nm=\"bv\" val=\"VMW71.00V.16707776.B64.2008070230\"/>\n      <arg nm=\"ram\" val=\"12288\"/>\n      <arg nm=\""
		"proccnt\" val=\"4\"/>\n      <arg nm=\"proclsp\" val=\"2295\"/>\n      <arg nm=\"wscpusc\" val=\"0\"/>\n      <arg nm=\"wsdsksc\" val=\"0\"/>\n      <arg nm=\"wscpudn\" val=\"Intel(R) Xeon(R) Gold 6140 CPU @ 2.30GHz\"/>\n      <arg nm=\"wsdgsc\" val=\"0\"/>\n      <arg nm=\"aoac\" val=\"0\"/>\n      <arg nm=\"bssku\" val=\"\"/>\n      <arg nm=\"chid\" val=\"{e66fedaa-d317-5223-84c7-2eb45f71c90f}\"/>\n      <arg nm=\"sdksz\" val=\"350\"/>\n     </hw>\n     <ctrl>\n      <arg nm=\"tm\" val=\""
		"133528960411155160\"/>\n      <arg nm=\"mid\" val=\"C2D308F8-25AB-49B9-9B4A-F8F443F15738\"/>\n      <arg nm=\"sample\" val=\"42234205\"/>\n      <arg nm=\"msft\" val=\"0\"/>\n      <arg nm=\"test\" val=\"0\"/>\n      <arg nm=\"scf\" val=\"0\"/>\n      <arg nm=\"commercialid\" val=\"\"/>\n      <arg nm=\"telemetry\" val=\"Optional\"/>\n     </ctrl>\n    </mach>\n   </desc>\n  </src>\n  <reqs>\n   <req key=\"1\">\n    <namespace svc=\"watson\" ptr=\"generic\" gp=\"generic\" app=\"msedge.exe\">\n    "
		" <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"121.0.2277.128\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\"121.0.2277.128\"/>\n     <arg nm=\"p5\" val=\"3081623\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n    </namespace>\n    <ctrl>\n     <arg nm=\"reportid\" val=\"2443afbe-a849-4bd9-bd0c-361db6211671\"/>\n     <arg nm=\"procmeta.Channel\" val=\"\"/>\n     <arg nm=\""
		"procmeta.MetricsClientId\" val=\"ef638bb3-0e27-43db-b180-ab00c9ce58ac\"/>\n     <arg nm=\"procmeta.MetricsClientIdHash\" val=\"-6926658363340494177\"/>\n     <arg nm=\"procmeta.MetricsSessionId\" val=\"190\"/>\n     <arg nm=\"procmeta.OfficialBuild\" val=\"1\"/>\n     <arg nm=\"procmeta.RuntimeVariationsSeedETag\" val=\"&quot;9JTaHLbLIoXB8Hrf7MmbKc5uR2GodGlO3xbl+MUBQBk=&quot;\"/>\n     <arg nm=\"procmeta.UXConfigCorrelationId\" val=\"32qeUCA7hshktCZh1abcGQK57j/DHwPFKIKKw/Hmq4I=\"/>\n     <arg nm="
		"\"procmeta.VariationsSeedETag\" val=\"&quot;F/zUWDW+09rQDFO6edSJk63EBQwCd9N0H2Q+GJfAJm8=&quot;\"/>\n    </ctrl>\n    <cmd nm=\"event\">\n     <arg nm=\"eventtype\" val=\"crashpad_exp\"/>\n     <arg nm=\"cat\" val=\"generic\"/>\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"121.0.2277.128\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\"121.0.2277.128\"/>\n     <arg nm=\"p5\" val=\"3081623\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\""
		"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n     <arg nm=\"appsessionguid\" val=\"000011b8-0002-0045-8a9b-44cbe163da01\"/>\n    </cmd>\n   </req>\n  </reqs>\n </tlm>\n</req>\n", 
		LAST);

	web_add_cookie("MUID=3FB288A77D7E6FC13A379A107C2C6E33; DOMAIN=business.bing.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=business.bing.com");

	web_add_cookie("SRCHUID=V=2&GUID=3BE0431A9B0049D9A20B0E44F490E096&dmnchg=1; DOMAIN=business.bing.com");

	web_add_cookie("BFBUSR=BAWAS=1&BAWFS=1; DOMAIN=business.bing.com");

	web_add_cookie("EDGSRCHHPGUSR=CIBV=1.1381.6; DOMAIN=business.bing.com");

	web_add_cookie("MMCASM=ID=6E55BF8A41D34AF1809D98A5E19C384F; DOMAIN=business.bing.com");

	web_add_cookie("SRCHUSR=DOB=20230213&T=1698225268000&POEX=O; DOMAIN=business.bing.com");

	web_add_cookie("MSPTC=M1lGh5yqbabjCw7GoRAs0oLa6tkYQLtr08CoubDts8g; DOMAIN=business.bing.com");

	web_add_cookie("BFB=AxCR6CgGimOBjyqcah_dBGI9wXkprpt0yG0Dt3mdhm5kuQ6RSAW11VQ-gfClbsoI9KCjdPigd2qlLBVe5MIOBRAta1qy5rDUCombKC-iEOozY2RjkO-U1aSls-wStFxiWrJgrmkKVUxw3e4Rl5QJFn4pm3sfF3Oyum27ZYuoe-3HdNEYA3cSzhMcPiM57krn8WY; DOMAIN=business.bing.com");

	web_add_cookie("ABDEF=V=13&ABDV=13&MRNB=1708062905830&MRB=0; DOMAIN=business.bing.com");

	web_add_cookie("USRLOC=HS=1&ELOC=LAT=12.949281692504883|LON=77.60128021240234|N=Bengaluru%20South%2C%20Karnataka|ELT=9|&CLOC=LAT=12.9378|LON=77.547|A=10476|TS=240220094421|SRC=I&BID=MjQwMjIwMTUxNDIxXzQ2YzJjNGFkMGMyYTllYWFkYmE1OTNjZjRhNjI1NGI2MTYyNDYxZWZlMTcxZmJiN2RkMjAwZGQ0MmRhNDZmOTE=; DOMAIN=business.bing.com");

	web_add_cookie("ACL=AxCAzqzlRj5Qq3S_ORNwKnkrXk747-6kBVJx2XXBvhiC1fD3vba4Ya4mjy0A5L1g4LYAII7u2cEbNj6j2pcrpHod; DOMAIN=business.bing.com");

	web_add_cookie("ACLUSR=T=1708067764000; DOMAIN=business.bing.com");

	web_add_cookie("_RwBf=r=0&ilt=145&ihpd=0&ispd=6&rc=200&rb=0&gb=0&rg=200&pc=200&mtu=0&rbb=0&g=0&cid=&clo=0&v=6&l=2024-02-15T08:00:00.0000000Z&lft=0001-01-01T00:00:00.0000000&aof=0&o=2&p=&c=&t=0&s=0001-01-01T00:00:00.0000000+00:00&ts=2024-02-16T07:33:14.9219998+00:00&rwred=0&wls=&wlb=&lka=0&lkt=1&TH=&aad=1&ccp=&wle=&ard=0001-01-01T00:00:00.0000000&rwdbt=0001-01-01T00:00:00.0000000&rwflt=0001-01-01T00:00:00.0000000; DOMAIN=business.bing.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANG=en&IG=217787DD2E274ED1BC5861A2916D2D51&PV=10.0.0&BRW=N&BRH=S&CW=1232&CH=606&SCW=1217&SCH=2911&DPR=1.0&UTC=330&DM=0&EXLTT=31&HV=1708068795&WTS=63833822068&PRVCW=1232&PRVCH=606&CIBV=1.1573.4&SPLSCR=0&PASPLT=2&BZA=0; DOMAIN=business.bing.com");

	web_add_cookie("OID=AxDCRNvr9UGoXKZWGL0sgUtDk8X4BseDgxE46UQceyktAMZ9kW7QhBcaKfhit5Gx7V7nLbUlhDW9qz7RRrsv8Rv-; DOMAIN=business.bing.com");

	web_add_cookie("OIDI="
		"gxDa1seF26V4Qu-A627JpSlzGy0m7uKcLPRQVAuvo-tkNHu1cV_Ir_KchO9ONNXrhIizWEKQrY7THbnh99wHSHsoz_tgNlN_JymTI2_L9DH-ZCwaNRteN78Txc7uPeWAqWHh5P8ETekHs3VTOXTbPe4Md47tA0URm82ZFWM5E4ida_9p8GNOigvA2-nodwZp783CeXzJcbCZlBGH5vSllebL3KbablV-UVPxBN17MmMXy1MfgjDI9EjBpQjIp4Tmjw32sATrzYn4iecNX7ckfpkTgzAX2OUSKTGjGj38NeWhDBRqE3WRhOSvc99PDEgJKffsopcCiNEL4oFyUBYWK_DfHnzyDGt1VbB_nxiq7t1XTLs3lmRrXe9HbKKpmk2rcg-Br5vCT2b-yUiNtKSbuysPvgoVbU6JTLHDD8Cw1sp1b-U6Jw4DD9QJ455uO5AK4buhp_MU1cEyz4Bb0nYIICiiY3KGBUbYGj7xyg4C4AJe16dfwGjsr2"
		"RtmF_9XHdAi9ry7Eh1OM3kOlCkH18hcRxjwT34sAW6dFdkAhzST0_r2PdEqDiofqV_zoyijW3MI0TSTDSswxzUGaIro1oUWz5i87hwzQ4CWd3BvNnsB4m42pJHCasFyE4GhOwwhqTvZllJU0NOwdYcS2FcDIfvx-Nw2wDAxlSsKqpkmDwqGHk1Bj2Q5TYuzKeyLe__G1BYhRpibqwWG2z6s_bDcZnkPAp_JedwMvi_TQ58rCuhIxstOhPY5739r-9TvMDmejOG6lddSOX4ZS7I9UMxuEulVZjMs3130zBw-RfEmQ7Zwp4_WraiUivg0su9x7PTRl1HIJyL7ct2Ni7nmNTRzEVnvp_nKpAl7nm5a3cC-GtSna9bFPXcIGxT5S6xxqeo3oWuZ6HeUpy2EcAWCmvERP6mR56RBucgpD4lyQVhryH1z1OdTXHneggoB_39GEqt1OnTRUzHMBEFLQv7k3WscsGYROSVoYKyax6D2TlGRVjfNYcX"
		"Pm-qalZROfxZ4z5-02b2inJpl42YTh6J0ZlB1abo2gBMXdb7ZJyRqzvw7ODOmlDj5ucCb0oYKRiUEjwzy-D8lJkhS0keAbLWvnJ0ozFa4T6ZFTNvl-SOP9E5w_nlX0JvV1dycicirAFmdXZyIQhgGq3OrCknzLJCCpNgbJexWQb74iO-ng9L2oIx4sVRo3-vjsEd3WcMx6_NtpLSmR1xavgIFwmlUEWTsrQ-StkrSU7LyYyFWHdjfzN15uMS5CUUQp6zXSM5riHUCI0JviqNfx_aYAJcXZkZMd4JOe3HS6Qp_o32YHMidGGeGNDRrBRCbRRCesIvyNLSKM0MlfG4mzE-VeIiBA-ULkT98NkkxJvq_EhnKBiiTQpZCsyGmyto5K9zPABYMlsLPBx0o0VWbCsXHONaT4q9mXKRMfOFlE1HNSi21AU0H9Nb5wDOmsgRyBa17wNRmquB-XfMof_dqfwe1O3nr6D4GWr8rHyQ2_KNwtO7QsYZmD"
		"Ybmkf-9LbvMybD8xPN0fpGJXmt8Na1aSJVGP4slb8-szxaXzC6h6H71Y4b7q58M3EyQPGixNcMFOY0i7EIQSslDNnk8raN0A48p6l1yJZTYNNKS4ms8nH4ErQZCgm3IAhKG9EnDovHlpqKm9-sbabKZ1A9P9UYEz-dTjsQJGuEaGc_4D81eMQ5JHaijudvmvDP2ItzQkueMbyUFeMDnWWpsJvZE7PiCIjSzRsX1YUxbSdg5NqVjL9YWgF5W5caNKkVQGEWhxgr9oDFlTUPb2QjgInd5TViPOJa6kRCroDoHls7l1cgLkVN54CPhUsoAe5vdHCNzOq083qbD-itMYxiQUcOhB_-XooWYw3GiSpZLNAz12e7nFnaeEuK5sfIKxzxPMgvnhA95Ma_4Mr-PyaHofCSglTT4xiL0qfiaPsxksFv0JPfymO6cJ3cu5m4RJY0vTod4l5537PyzIAbS9EB4Ws-poXVnTmCc-vDSwZ_u02-sj0s4AB8"
		"Sa-bGbuZQGcUplZDO7n2QQ; DOMAIN=business.bing.com");

	web_add_cookie("OIDR="
		"gxAh8W_evzmtOFgP0dx3ZHrygteWCLDfrbVa_V4CCZfFhU0F_khOABysW-pIPJfxDDgDy8ONDStZC8y_KftEoBHFRVYNbyLmHGq_nicNKpnvGKQveg-pHY87mRm_-WxZQsqXSXwKHn2XoxXeqUuuk-LbhT2Q6SCaBpefgxacLJ_-RTPxeWB52uhW4C5fQd2CdI1fvf703tFG-IT1U9mdpb472RGPeTgVoAroQHjkR7dBTh_ceUMNehanasTgwAyqW3Y7IAJKB2GfMcPJxEBIhNnX1fFfg1JZW5F-OEw1qVK9obOczXDhoZ-SSGchWBrQ58cCktnzpaHch8-2RS5WZ_KUeT0XLxwsoW_KW6rKMGbgfjo_nUAzBfp7sGu2JZwvt4xw5RoNpX1qobm8U1UsTlQD5bBsvePzct-DN-6BUnNTOxsx8rGKMXpkJh_XXqhOMykWkpAubJKvxHHe7Gk7H6uDrvTo7RMvIK52p44DNoY-KmeTelhj2-"
		"Dsa2DnN9b4LI332Md_ORH8zTktm-_lXODgSN0DBQUh-2o_EGpnnr4Oppc0a1p_Ddj6rSbkV49odfj7QdI59bjXQZSkzYGq2LCWDm4IRM2aVZMqlea9sT6iy4LKxR34e0VpvGqRgK7gawuH39hEgWQu6yG_GSb_gSAnkF-ELlbNl_YPX-XhZlt6N_i2zr7YIfjpuJzTVB8jAjQrCiAqnzHaUeKBZSo9cgI6qauOqOe-Nl7Gv56Ba0TPzE3MH74dHuEIRUSUN3NU_ou1u3UyI3qORP0apGaK9BIciuO62oksuwo9CsVRlSHa8t3Kr_MmttwAVyyTD6uWE7JJqLV--oBT8Z4ni7uU3iNFzDdXTydBOCGc8MfepT4av7zS8RD8UpyuxA26DRxF7nL5_75UDwFQDuMhpaC3oVNk8JBKjq3EdRIkGN9u_WDmptQ_nwpbJIT_bFM_naRjTdiAGh5M9zugk4SsLr15u7ytkjP4gjtH5uokSd3e0Y7d"
		"S90QSEZPShsyZhLnhs8LWgSrgtU1MtF7XYrqvCDMARvqtcZsNZs0aihZ93G8jUDYIcj3WlktdmIb9NHilLjGtnAx99jlGFNlAI447vsxmjJvA_WIOFldBJ-KIVbO3ISUN0x59jH2kclnPwv7BczM9t7JsZrKw66YW2uqIIyYjH0L; DOMAIN=business.bing.com");

	web_url("settingswithflights", 
		"URL=https://business.bing.com/work/api/v2/tenant/my/settingswithflights?&clienttype=edge-omnibox", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_custom_request("report", 
		"URL=https://bzib.nelreports.net/api/report?cat=bingbusiness", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("report_2", 
		"URL=https://bzib.nelreports.net/api/report?cat=bingbusiness", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/reports+json", 
		"Body=[{\"age\":2,\"body\":{\"elapsed_time\":3877,\"method\":\"GET\",\"phase\":\"application\",\"protocol\":\"http/1.1\",\"referrer\":\"\",\"sampling_fraction\":1.0,\"server_ip\":\"13.107.6.158\",\"status_code\":401,\"type\":\"http.error\"},\"type\":\"network-error\",\"url\":\"https://business.bing.com/api/v1/user/token/microsoftgraph?&clienttype=edge-omnibox\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/"
		"121.0.0.0\"}]", 
		LAST);

	lr_think_time(19);

	web_url("config.json", 
		"URL=https://edge-consumer-static.azureedge.net/mouse-gesture/config.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(13);

	web_custom_request("login", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"email\":\"vishnu1998thulasi@gmail.com\",\"password\":\"12345678\"}", 
		LAST);

	web_url("contactList", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("3", 
		"URL=https://nav-edge.smartscreen.microsoft.com/api/browser/edge/navigate/3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0\",\"identity\":{\"user\":{\"locale\":\"en-US\"},\"device\":{\"id\":null,\"customId\":null,\"onlineIdTicket\":\"t=GwAWAd9tBAAU4MijKW4GiCCLggU/9urvxKw9DJgOZgAAEDP7AunG5upeQ2QCCOXbGcfgAL65M+OKmqqXQ3nokntUnxxZpxYYTwj69Yl+Qa4LSqcWqVCXZtIRZRwzOfQUKXTVCBPAqAO4twWICIs9FQ58dWy5AHd6x2NLhEtV7EU2c0g1kw20UPJDoX4fK2ls1zBtvtD5Bowq/"
		"Lw4f8YyZnzMKf9knttBuWxUz22Vwddevc4ojS6FI8IZtnsXfsknnasUwv7eo0y2YYe4wCtfrr8/dEGSZ+BjtQEqDT+QHbzyl6CaxBCqzaJAsOXOQngyQC1BnMinu/FrQTEaQjrxsNvwGMRVKti/8mkEyhE+lirnz1YaHQE=&p=\",\"family\":3,\"locale\":\"en-US\",\"osVersion\":\"10.0.19045.3324.vb_release\",\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"netJoinStatus\":2,\"enterprise\":{},\"cloudSku\":false,\"architecture\":9},\"caller\":{\"locale\":\"en-US\",\"name\":\"\",\"version\":\"121.0.2277.128 (Official build) \"},\"client\":{\"version\""
		":\"281483718098944\",\"data\":{\"topTraffic\":\"638004170464094982\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-48b11410dc937a1723bf4c5ad33ecdb286d8ec69544241bc373f753e64b396c1\",\"synchronousLookupUris\":\"638343870221005468\",\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\"}}},\"config\":{\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}},\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\""
		":\"warn\"}}},\"destination\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/contactList\",\"ip\":\"54.146.248.82\"},\"referrer\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/\",\"ip\":\"54.146.248.82\"},\"type\":\"top\",\"forceServiceDetermination\":false,\"correlationId\":\"7199776e-c88e-4810-9df6-47dbcca19c87\",\"synchronous\":false}", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("contacts", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("ExpandedDomainsFilterGlobal.json", 
		"URL=https://www.bing.com/bloomfilterfiles/ExpandedDomainsFilterGlobal.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}