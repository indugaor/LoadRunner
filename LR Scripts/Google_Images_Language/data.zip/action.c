Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("OTZ=7377535_34_34__34_; DOMAIN=accounts.google.com");

	web_add_cookie("SID=fAiynANxyPVWlCFdyW5m0PC1XO4rptdULh8a-zK96uZljS5rbgC5EmUrSDoLOYRPEJ9gDQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=fAiynANxyPVWlCFdyW5m0PC1XO4rptdULh8a-zK96uZljS5ro1-_tWSZxbv6gevG0MsI-w.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=fAiynANxyPVWlCFdyW5m0PC1XO4rptdULh8a-zK96uZljS5r5213LWMxWnnwKGvN3M6MtA.; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=A1mGkq_0DFVUNoy0p; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=AVMaomI9RdRZVcjZ9; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=LEpmEFSU_LJ4ft4A/ACwkHAgT0Xmz-ldTe; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=Dr4a-BobL1zNA9j3/AMgDITmBCca_elwDz; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=Dr4a-BobL1zNA9j3/AMgDITmBCca_elwDz; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=Dr4a-BobL1zNA9j3/AMgDITmBCca_elwDz; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI6bhbV7z54ecXHA4vXb3Q7bHI-knjthJLa409obhbizBpf6UUUT7H0qHUjRBrR_HWefjSFd0EKMH_sHcX7i53m8jMagZ2vwPmxAXXKvoZhSfeB5jvS_eOJvPDe5eqsLXENVBT9_; DOMAIN=accounts.google.com");

	web_add_cookie("SMSV=ADHTe-Cw_tuUZoAhOo81lLC1imLfHav48XHDCyOMIUf5dJQlc5lN8nWjOEjGYpZBMLzo6xKHCKHd4mJv4jdScuj9-dwehRQEMP5o9GYHNYwKYzWXma9OERY; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIlZoB; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:_bA6ISoJnwLnttOXHRbrujNwEZ8GHHRfXfOaaoMDaEOzOfbzHaEc4mFKemOdRtFmhyhl11_MpRSrXhGK3eI-we7QFWkAhA:5t1h04iMMeDf6Ko4; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=o.chat.google.com|o.chromewebstore.google.com|o.mail.google.com|o.meet.google.com|s.IN:fAiynDoPcK3QI8F_ori6wgB3OkMNLwTrOTqBxXAfroFq-eXvj2g39KC8H8ItHG0al_XC3Q.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=o.chat.google.com|o.chromewebstore.google.com|o.mail.google.com|o.meet.google.com|s.IN:fAiynDoPcK3QI8F_ori6wgB3OkMNLwTrOTqBxXAfroFq-eXvFiJanpT25-sNCIEbk5ecwg.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=o.chat.google.com|o.chromewebstore.google.com|o.mail.google.com|o.meet.google.com|s.IN:fAiynDoPcK3QI8F_ori6wgB3OkMNLwTrOTqBxXAfroFq-eXvmRT6O0foJb67edPSu_v10w.; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=rlLxJzrshciSA5QHVP5_TeQTZMeTOkpQQsgB-C1V1vYCiVNNEhHxLui0OR8v3Q9ILue4AIe2FxHrQh0nV7QNzcJU5EJWFiw2nJY7dnMGntq91g2Qrxs6SD3YeyelccmvY1-DxUkE16x1l18SlTjr7QnMigcqdv9eqTrpzceKwZtItHFvKmjGs5l5oy5zGH0l0c3DDZVt013wOAXUUUHgUAJ8oOzeptdHOHGb_AveamMxlt7ykabDJw7r4nPVJQiwNTVSOevrvKICKXceTJWGd4FmJ9bo1COpbki1Z-jQjE-50mB_tWsDHDK0T9jTEoVLNXSXauyH; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2024-02-03-09; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=Ae3NU9NEO8JkJtRMeNzbIo-vKij4NJJk7N9Hz_G0iiZZrY_dn8cSbJpQfFU; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDTS=sidts-CjIBPVxjSst_sDjDBpkgTBsWQ-CFLHlODLs-ocTY_44dPosFuTDQCK5VGAsplPK2PCURWxAA; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDTS=sidts-CjIBPVxjSst_sDjDBpkgTBsWQ-CFLHlODLs-ocTY_44dPosFuTDQCK5VGAsplPK2PCURWxAA; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=ABTWhQHgnlMvVtS2b4aQvY7X9hrqbXKhmhTZTjgTMAW-OWiQ_0K9oMFoLGlH_4BQaIBvbv40X9o; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDCC=ABTWhQFU87eOltX6lucBzHc-Vsmoc8IZt3LChkOAEyaEcb8V2IKmm-HMQwpVFM-gZDpmxsgllw; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=ABTWhQG-6ElTbW2_7yNem-Wn14ACVMIRXohkp9Im94jya35wkg6-hE4GZDsd9SzlUtMfXdR4_Q; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", 
		"Resource=1", 
		"RecContentType=application/x-gzip", 
		"Referer=", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("reqres.in", 
		"URL=https://reqres.in/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("DigiCertSHA2ExtendedValidationServerCA.crt", 
		"URL=http://cacerts.digicert.com/DigiCertSHA2ExtendedValidationServerCA.crt", 
		"Resource=1", 
		"RecContentType=application/pkix-cert", 
		"Referer=", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("monetization.custom.js", 
		"URL=https://m.servedby-buysellads.com/monetization.custom.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://reqres.in/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("v3", 
		"URL=https://js.stripe.com/v3/", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://reqres.in/", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("logo.png", 
		"URL=https://reqres.in/img/logo.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://reqres.in/", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("app.css", 
		"URL=https://reqres.in/css/app.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://reqres.in/", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("swagger-logo-horizontal.jpeg", 
		"URL=https://reqres.in/img/swagger-logo-horizontal.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://reqres.in/", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("email-decode.min.js", 
		"URL=https://reqres.in/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://reqres.in/", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("app.js", 
		"URL=https://reqres.in/js/app.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://reqres.in/", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("classic-10_7.css", 
		"URL=https://cdn-images.mailchimp.com/embedcode/classic-10_7.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://reqres.in/", 
		"Snapshot=t23.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "0");

	web_set_sockets_option("TLS_SNI", "1");

	lr_think_time(14);

	web_custom_request("users", 
		"URL=https://reqres.in/api/users?page=2", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://reqres.in/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_concurrent_start(NULL);

	web_url("carbon.js", 
		"URL=https://cdn.carbonads.com/carbon.js?serve=CE7D6K3E&placement=reqresin", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://reqres.in/", 
		"Snapshot=t25.inf", 
		LAST);

	web_url("analytics.js", 
		"URL=https://www.google-analytics.com/analytics.js", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://reqres.in/", 
		"Snapshot=t26.inf", 
		LAST);

	web_url("css", 
		"URL=https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Source%20Code%20Pro:500", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t27.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("m-outer-3437aaddcdf6922d623e172c2d6f9278.html", 
		"URL=https://js.stripe.com/v3/m-outer-3437aaddcdf6922d623e172c2d6f9278.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://reqres.in/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_custom_request("reports", 
		"URL=https://nel.heroku.com/reports?ts=1707118570&sid=c4c9725f-1ab0-44d8-820f-430df2718e11&s=rg1v3LSfhYWAKYNLCxCcqdZSN8n8tixXrVjweAK0ipU%3D", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_url("m-outer-15a2b40a058ddff1cffdb63779fe3de1.js", 
		"URL=https://js.stripe.com/v3/fingerprinted/js/m-outer-15a2b40a058ddff1cffdb63779fe3de1.js", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://js.stripe.com/v3/m-outer-3437aaddcdf6922d623e172c2d6f9278.html", 
		"Snapshot=t30.inf", 
		LAST);

	web_custom_request("reports_2", 
		"URL=https://nel.heroku.com/reports?ts=1707118570&sid=c4c9725f-1ab0-44d8-820f-430df2718e11&s=rg1v3LSfhYWAKYNLCxCcqdZSN8n8tixXrVjweAK0ipU%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=application/reports+json", 
		"Body=[{\"age\":3,\"body\":{\"elapsed_time\":10455,\"method\":\"GET\",\"phase\":\"application\",\"protocol\":\"http/1.1\",\"referrer\":\"https://reqres.in/\",\"sampling_fraction\":0.005,\"server_ip\":\"104.26.10.213\",\"status_code\":200,\"type\":\"ok\"},\"type\":\"network-error\",\"url\":\"https://reqres.in/css/app.css\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\"}]", 
		LAST);

	web_custom_request("CEBIP53J.json", 
		"URL=https://srv.buysellads.com/ads/CEBIP53J.json?segment=placement:reqresin-sponsor", 
		"Method=OPTIONS", 
		"Resource=1", 
		"Referer=https://reqres.in/", 
		"Snapshot=t32.inf", 
		LAST);

	web_url("CEBIP53J.json_2", 
		"URL=https://srv.buysellads.com/ads/CEBIP53J.json?segment=placement:reqresin-sponsor", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://reqres.in/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_url("gtm.js", 
		"URL=https://www.googletagmanager.com/gtm.js?id=GTM-KB622KF", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://reqres.in/", 
		"Snapshot=t34.inf", 
		LAST);

	web_custom_request("collect", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=379021412&t=pageview&_s=1&dl=https%3A%2F%2Freqres.in%2F&ul=en-gb&de=UTF-8&dt=Reqres%20-%20A%20hosted%20REST-API%20ready%20to%20respond%20to%20your%20AJAX%20requests&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=IEBAAEABAAAAACAAI~&jid=673040654&gjid=566140478&cid=428343557.1707213281&tid=UA-55888877-1&_gid=1026438250.1707213281&_r=1&_slc=1&z=1456414954", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://reqres.in/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	web_concurrent_start(NULL);

	web_url("js", 
		"URL=https://www.googletagmanager.com/gtag/js?id=UA-174008107-1", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://reqres.in/", 
		"Snapshot=t36.inf", 
		LAST);

	web_url("v84a3a4012de94ce1a686ba8c167c359c1696973893317", 
		"URL=https://static.cloudflareinsights.com/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t37.inf", 
		LAST);

	web_url("868803", 
		"URL=https://avatars.githubusercontent.com/u/868803?v=4", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t38.inf", 
		LAST);

	web_url("css.svg", 
		"URL=https://cdn.jsdelivr.net/gh/PKief/vscode-material-icon-theme@master/icons/css.svg", 
		"Resource=1", 
		"RecContentType=image/svg+xml", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t39.inf", 
		LAST);

	web_url("npm.svg", 
		"URL=https://cdn.jsdelivr.net/gh/PKief/vscode-material-icon-theme@master/icons/npm.svg", 
		"Resource=1", 
		"RecContentType=image/svg+xml", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t40.inf", 
		LAST);

	web_url("typescript.svg", 
		"URL=https://cdn.jsdelivr.net/gh/PKief/vscode-material-icon-theme@master/icons/typescript.svg", 
		"Resource=1", 
		"RecContentType=image/svg+xml", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t41.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "0");

	web_set_sockets_option("TLS_SNI", "1");

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("collect_2", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=379021412&t=pageview&_s=1&dl=https%3A%2F%2Freqres.in%2F&ul=en-gb&de=UTF-8&dt=Reqres%20-%20A%20hosted%20REST-API%20ready%20to%20respond%20to%20your%20AJAX%20requests&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=aEDAAUABAAAAACAAI~&jid=1841325795&gjid=1724609736&cid=428343557.1707213281&tid=UA-174008107-1&_gid=1026438250.1707213281&_r=1&gtm=457e41v0za200&gcd=13l3l3l3l1&dma=0&jsscut=1&z=1982823989", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://reqres.in/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_custom_request("command", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=tRolqVEUduhk43ZiNNi2wA%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t43.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x15indugowra98@gmail.com\\x10c\\x18\\x02*'\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\\x04\\x08\\xDE\\xD8\\x122\\x13\\x08\\x81\\xF5\\x02\\x12\r \\x00\\x88\\x01\\xDF\\xCB\\xF7\\xF5\\xB1\\xAB\\xD4\\xB4\\x01@\\x00H\\x07:%z00000169-3d5a-eb4c-0000-00005c7a33f2R\\x18\n\\x02\\x08\\x05\n\\x02\\x08\t\n\\x02\\x08\n\n\\x04\\x18\\x9A\\xB7\t\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 121.0.6167.140 (a5856993c61543d4acbee5f848f1750607e87ba0-refs/branch-heads/6167@{#1684}) channel"
		"(stable),gzip(gfe)b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	web_custom_request("collect_3", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-CESXN06JTW&gtm=45je41v0v9136517129za200&_p=1707213265666&gcd=13l3l3l3l1&npa=0&dma=0&cid=428343557.1707213281&ul=en-gb&sr=1280x720&uaa=x86&uab=64&uafvl=Not%2520A(Brand%3B99.0.0.0%7CGoogle%2520Chrome%3B121.0.6167.140%7CChromium%3B121.0.6167.140&uamb=0&uam=&uap=Windows&uapv=10.0.0&uaw=0&are=1&pscdl=noapi&_eu=AAAI&_s=1&sid=1707213281&sct=1&seg=0&dl=https%3A%2F%2Freqres.in%2F&dt="
		"Reqres%20-%20A%20hosted%20REST-API%20ready%20to%20respond%20to%20your%20AJAX%20requests&en=page_view&_fv=1&_ss=1&tfd=18490", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://reqres.in/", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("KFOlCnqEu92Fr1MmEU9fBBc4.woff2", 
		"URL=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fBBc4.woff2", 
		"Resource=1", 
		"RecContentType=font/woff2", 
		"Referer=https://fonts.googleapis.com/", 
		"Snapshot=t45.inf", 
		LAST);

	web_custom_request("command_2", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=tRolqVEUduhk43ZiNNi2wA%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t46.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x15indugowra98@gmail.com\\x10c\\x18\\x02*\\xC4\\x03\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\"\\x08\\xDE\\xD8\\x12\\x12\\x0C \\x00x\\x00\\x80\\x01\\xBC\\xC1\\xFF\\xEE\\xD71*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\xCE\\x01\\x08\\x9A\\xB7\t\\x12\\xB7\\x01 \\x00\\x92\\x01\\xB1\\x01\nh\n\\x0Echrome_sync_di\\x12\\x0551!di\\x1A\\x12\t\\x02\\xCC\\xC4\\xFC\\xB0\\x10\\x06\\x00\\x11\\x02\\xCC\\xC4\\xFC\\xB0\\x10\\x06\\x00\"2\t"
		"\\xD1\\xF6\\xBC\\xFC\\xB0\\x10\\x06\\x00\\x10\\x01\\x19hW\\xAA\\x98\\xAF\\x13\\xD7\\x07 \\x01*\\x1A51!di:11697764700780635538)_-\\xC7\\xFC\\xB0\\x10\\x06\\x00\nE\n\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\\x8BS\\xF7\\xB0\\x10\\x06\\x00\\x11\\x80\\x8BS\\xF7\\xB0\\x10\\x06\\x00)\\xDE\\xCA\\xC4\\xFC\\xB0\\x10\\x06\\x000\\x80\\x97\\xCE\\xBA\\x8F\\x96\\x84\\x03*\\x0E\\x10\\x00\\x18\\x01 \\x01(\\x000\\x008\\x00@\\x002\\x99\\x01\\x08\\xFC\\xDE$\\x12\\x82\\x01 \\x00\\x92\\x01}\n4\n"
		"\\x0Echrome_sync_st\\x12\\x0551!st\\x1A\\x12\t\\x02\\xCC\\xC4\\xFC\\xB0\\x10\\x06\\x00\\x11\\x02\\xCC\\xC4\\xFC\\xB0\\x10\\x06\\x00)r-\\xC7\\xFC\\xB0\\x10\\x06\\x00\nE\n\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\\x8BS\\xF7\\xB0\\x10\\x06\\x00\\x11\\x80\\x8BS\\xF7\\xB0\\x10\\x06\\x00)\\xDE\\xCA\\xC4\\xFC\\xB0\\x10\\x06\\x000\\x80\\x97\\xCE\\xBA\\x8F\\x96\\x84\\x03*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002#\\x08\\x81\\xF5\\x02\\x12\r "
		"\\x00\\x88\\x01\\xDF\\xCB\\xF7\\xF5\\xB1\\xAB\\xD4\\xB4\\x01*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00@\\x00H\\x0CP\\x00:%z00000169-3d5a-eb4c-0000-00005c7a33f2R\\x16\n\\x0E\\x12\\x0C8\\x00@\\x00R\\x04\\x08\\x00\\x10\\x00`\\x07\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 121.0.6167.140 (a5856993c61543d4acbee5f848f1750607e87ba0-refs/branch-heads/6167@{#1684}) channel(stable),gzip(gfe)b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	web_custom_request("collect_4", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-WSM10MMEKC&gtm=45je41v0v9125911393za200&_p=1707213265666&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=428343557.1707213281&uaa=x86&uab=64&uafvl=Not%2520A(Brand%3B99.0.0.0%7CGoogle%2520Chrome%3B121.0.6167.140%7CChromium%3B121.0.6167.140&uamb=0&uam=&uap=Windows&uapv=10.0.0&uaw=0&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=https%3A%2F%2Freqres.in%2F&dt=Reqres%20-%20A%20hosted%20REST-API%20ready%20to%20respond%20to%20your%20AJAX%20requests&sid="
		"1707213282&sct=1&seg=0&en=page_view&_fv=1&_ss=1&_ee=1&tfd=18655", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://reqres.in/", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_concurrent_start(NULL);

	web_url("KFOmCnqEu92Fr1Mu4mxK.woff2", 
		"URL=https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxK.woff2", 
		"Resource=1", 
		"RecContentType=font/woff2", 
		"Referer=https://fonts.googleapis.com/", 
		"Snapshot=t48.inf", 
		LAST);

	web_url("KFOlCnqEu92Fr1MmWUlfBBc4.woff2", 
		"URL=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc4.woff2", 
		"Resource=1", 
		"RecContentType=font/woff2", 
		"Referer=https://fonts.googleapis.com/", 
		"Snapshot=t49.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("command_3", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=tRolqVEUduhk43ZiNNi2wA%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t50.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x15indugowra98@gmail.com\\x10c\\x18\\x01\"\\xEF\\x0B\n\\xF2\\x06\nfZ:ADqtAZzSnFnKd7e0F+iaWdOQw8uajFgvZmoKgFkqlfa4/q30ibO1PYiBeAevkrT1kg5MXVTOTX1Fwu9AUMImgm5r0KMTFTfQnw== \\xD1\\xED\\xF3\\xE5\\x8F\\x96\\x84\\x03(\\x92\\xA8\\xDC\\xEE\\xD710\\xC1\\x9E\\xB9\\xBA\\xCF1:\tVMware7,1\\x90\\x01\\x00\\xAA\\x01\\xC2\\x05\\xD2\\xB9K\\xBD\\x05\n\\x18tRolqVEUduhk43ZiNNi2wA==\\x12\tVMware7,1\\x18\\x01\"sChrome WIN 121.0.6167.140 (a5856993c61543d4acbee5f848f1750607e87ba0-refs/branch-heads/6167@"
		"{#1684}) channel(stable)*\\x0E121.0.6167.140:$35389c56-0979-47ef-a16c-7d6d8017595c@\\x92\\xA8\\xDC\\xEE\\xD71J\\x02\\x08\\x01R\\xFA\\x01\n\\x00\\x12\\x00\\x1A\\x00 \\x04 \\x08B\\x98\\x01eat25KuoXvs:APA91bHMicFpDxdjTJ8Fxk2H9a_wozhHtJe4vYLigCRbjzqbH7Wx8Hy3esZ0kvZBo2n8C_RUcwxTxyhQMcZBFMQoKtYmbez0OAfJsSa5wP8XbjIhGlbjrASnvi98xjSNx6UXp6SPKu3vJA\\x04\\x11\\xAB\\xAD\\xF8\\xC9Ce\\x02\\x11\\xD5\\xCD\\xC5\\xE4\\xDA0`\\xA1\\xD8*\\x91RXlkg\\x93\\xE5\\x81\\xBB\\xF0\\xCAg\\x1B;\\xD6\\xD7w?"
		"\\x07D\\xF1a-\\x01\\xBA\\xB8 5u\\x06\\xEA\\xE8\\xC9\\x02\\xDA\\xF3f\\x16\\xA9\\x9E\\xCA\\xB9\\xBB7R\\x10\\x1B\\x1D\\xB2\\xCDH\\x18\\xF4\\xC4\\xA8\\x0C\\xF3\\x1Fy\\x97\\xED\\x8EZ\tVMware7,1b\\x0CVMware, Inc.h\\xA0\\x0Br\\xAB\\x01\n\\x98\\x01fJ7EZTFTV5g:APA91bHwzLq5k5CpBxc9xS7kxXQ_SI-MjPiHgkbxf4mvm2F2BAQB1LFvkRdAYccVE7F74b3yyshmQ3PU5BL5sDCxKhYfpBg7PW71n4JrwV5EzJLKQbirTwn4IpUm51Ri7AaQ2liSy-fq\\x10\\xDE\\xD8\\x12\\x10\\x9A\\xB7\t\\x10\\xFC\\xDE$\\x10\\x81\\xF5\\x02\\x8A\\x01\\x10\n"
		"\\x0E121.0.6167.140\\x98\\x01\\x01\\xA0\\x01\\x01\\xBA\\x01\\x1CIGF2oU+cd49FXfrt2ZkdoI+rlVo=\\x12\\x18tRolqVEUduhk43ZiNNi2wA==\"\\xDA\\x02\\x08\\xDE\\xD8\\x12\\x08\\x9A\\xB7\t\\x08\\xEE\\xF7!\\x08\\xFC\\xDE$\\x08\\xB4\\xD2$\\x08\\xA2\\xBE,\\x08\\x81\\xF5\\x02\\x18\\x00 \\x00*\\x98\\x01fdMZswGAHWc:APA91bEs5vJHMcrhG15B95fYX7Ks9oqwSiyYXfKp3ZZGyX_alqu9NlTZVgY5Ib0sUkClUNN19-iwCmd-HbuOQVn4n0IfjD2z9Hhz3uT705XMUZ7qpjbaz_QduxuP97VqYJKspK1hjbo60\\x00:\\x98\\x01fdMZswGAHWc"
		":APA91bEs5vJHMcrhG15B95fYX7Ks9oqwSiyYXfKp3ZZGyX_alqu9NlTZVgY5Ib0sUkClUNN19-iwCmd-HbuOQVn4n0IfjD2z9Hhz3uT705XMUZ7qpjbaz_QduxuP97VqYJKspK1hjbo6@\\x012\\x80\\x02XIR&`\"6TE-:Wh4 6:yno!.6E18zYDx7/w~v`Rc#bgh6^I.wSrjNANH(MZk's*0OesPx&%e}!7UF/6E+s|;P0im^X._KB&MBV$?GiOieG!%~!1Qx(Uj43 !Hzt1@~okn(g0)Z<^+aV< Cw[~ug?-m49b3T1;#e{oh1'- =qJ}Qj#|pSZpqe5F:If &_b5]_>qKob*U/,XEs<o6n*9Rp,\\\\\"9:gWR~{/~m`R H? au8mU+6=$v3%T04~sxa|da^B&qp:%z00000169-3d5a-eb4c-0000-00005c7a33f2R\\x06\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01"
		"\n\\x7F\\x12}Chrome WIN 121.0.6167.140 (a5856993c61543d4acbee5f848f1750607e87ba0-refs/branch-heads/6167@{#1684}) channel(stable),gzip(gfe)b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_concurrent_start(NULL);

	web_url("jsconfig.json", 
		"URL=https://raw.githubusercontent.com/SchemaStore/schemastore/master/src/schemas/json/jsconfig.json", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t51.inf", 
		LAST);

	web_url("tsconfig.json", 
		"URL=https://raw.githubusercontent.com/SchemaStore/schemastore/master/src/schemas/json/tsconfig.json", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t52.inf", 
		LAST);

	web_url("package.json", 
		"URL=https://raw.githubusercontent.com/SchemaStore/schemastore/master/src/schemas/json/package.json", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t53.inf", 
		LAST);

	web_url("prettierrc.json", 
		"URL=https://raw.githubusercontent.com/SchemaStore/schemastore/master/src/schemas/json/prettierrc.json", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=https://codesandbox.io/", 
		"Snapshot=t54.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "0");

	lr_think_time(4);

	web_custom_request("command_4", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=tRolqVEUduhk43ZiNNi2wA%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t55.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x15indugowra98@gmail.com\\x10c\\x18\\x02*\\x8F\\x03\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\"\\x08\\xDE\\xD8\\x12\\x12\\x0C \\x00x\\x00\\x80\\x01\\xBC\\xC1\\xFF\\xEE\\xD71*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x99\\x01\\x08\\x9A\\xB7\t\\x12\\x82\\x01 \\x00\\x92\\x01}\n4\n\\x0Echrome_sync_di\\x12\\x0551!di\\x1A\\x12\tn\\x84\\x8B\\xB2\\xB3\\x10\\x06\\x00\\x11n\\x84\\x8B\\xB2\\xB3\\x10\\x06\\x00)\\x94\\x07\\x8D\\xB2\\xB3\\x10\\x06\\x00\nE\n"
		"\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\\xD9\\x1F\\xAD\\xB3\\x10\\x06\\x00\\x11\\x80\\xD9\\x1F\\xAD\\xB3\\x10\\x06\\x00)\\x80\\x83\\x8B\\xB2\\xB3\\x10\\x06\\x000\\x80\\xB3\\xFF\\xE8\\xBA\\x96\\x84\\x03*\\x0E\\x10\\x00\\x18\\x01 \\x01(\\x000\\x008\\x00@\\x002\\x99\\x01\\x08\\xFC\\xDE$\\x12\\x82\\x01 \\x00\\x92\\x01}\n4\n\\x0Echrome_sync_st\\x12\\x0551!st\\x1A\\x12\tn\\x84\\x8B\\xB2\\xB3\\x10\\x06\\x00\\x11n\\x84\\x8B\\xB2\\xB3\\x10\\x06\\x00)"
		"\\xA4\\x07\\x8D\\xB2\\xB3\\x10\\x06\\x00\nE\n\\x16annotation_chrome_sync\\x12\\x0551!bd\\x1A\\x12\t\\x80\\xD9\\x1F\\xAD\\xB3\\x10\\x06\\x00\\x11\\x80\\xD9\\x1F\\xAD\\xB3\\x10\\x06\\x00)\\x80\\x83\\x8B\\xB2\\xB3\\x10\\x06\\x000\\x80\\xB3\\xFF\\xE8\\xBA\\x96\\x84\\x03*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002#\\x08\\x81\\xF5\\x02\\x12\r \\x00\\x88\\x01\\xDF\\xCB\\xF7\\xF5\\xB1\\xAB\\xD4\\xB4\\x01*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00@\\x00H\\x0CP\\x00"
		":%z00000169-3d5a-eb4c-0000-00005c7a33f2R\\x1C\n\\x0E\\x12\\x0C8\\x00@\\x00R\\x04\\x08\\x00\\x10\\x00`\\x0C\n\\x04\\x18\\x9A\\xB7\t\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 121.0.6167.140 (a5856993c61543d4acbee5f848f1750607e87ba0-refs/branch-heads/6167@{#1684}) channel(stable),gzip(gfe)b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("package.json_2", 
		"URL=https://unpkg.com/@babel/runtime@%5E7.3.1/package.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://j17lt.csb.app/", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("package.json_3", 
		"URL=https://unpkg.com/@babel/core@%5E7.3.3/package.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://j17lt.csb.app/", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		LAST);

	web_url("react@17.0.0", 
		"URL=https://unpkg.com/react@17.0.0/?meta", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://j17lt.csb.app/", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		LAST);

	web_url("runtime@7.23.9", 
		"URL=https://unpkg.com/@babel/runtime@7.23.9/?meta", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://j17lt.csb.app/", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=13:FIJKeTnAjcuGFwkxpW7HQdzwUpI76NE9WIfzOiu3hvM&cup2hreq=07a9179662dcc7baf9b9d8d8f99d7596b8e36b050200c98cb63b86ec717a0551", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.aeedb246d19256a956fedaa89fb62423ae5bd8855a2a1f3189161cf045645a19\"}]},\"ping\":{\"ping_freshness\":\"{c667a3af-154d-4561-b071-e2708e2aefc0}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"1.3.36.141\"},{\"appid\":\""
		"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\"{ddde74c1-d3b9-4000-93c1-7752c9074b15}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohortname"
		"\":\"Chrome 106+\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{e452842c-8b7a-467a-994b-8a7bb5c298c1}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f/20ol/20or:\",\"cohortname\":\"Control\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.b9685d1e3054ce061c8c804b6e8983c6f62deb37d3882c2de2ef300666e91af3\"}]},\"ping\":{\"ping_freshness\":\"{afab7be6-1e0d-4397-97d4-d1c8fdfe9ef2}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"20230916.567854667.14\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:27p3@0.025\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cadbf9a5f27721576d77d35576f37ca01ac34d86bce73958bf71cde62af71b48\"}]"
		"},\"ping\":{\"ping_freshness\":\"{4cb312bd-9642-4cce-9f44-462d1a4fe7de}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"432\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{b0ca0a11-39c2-44b4-9ae0-79e70bcb63eb}\",\"rd\":6244},\""
		"updatecheck\":{},\"version\":\"9.49.1\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6132,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4a6508925b2ffec931c1e3931ddeb15ca41d820a8264cd5a962b526e9932bcdf\"}]},\"ping\":{\"ping_freshness\":\"{e21cce0e-90a6-4ca1-8a24-1c7d8ad7e069}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2024.1.2.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\""
		"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{8551d311-e089-4e7a-9742-051ef888b589}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887"
		",\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.90f54a8ca8c3135f647fedbb5f38ecadbbae4d45dafc3b73cde0c96d924a1773\"}]},\"ping\":{\"ping_freshness\":\"{b892b47d-f518-4a68-bb38-98622cc9131b}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"8531\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\"ping_freshness\":\"{798e234b-fa4f-4c78-8ce6-5f7b48d8b0b4}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{9e545d68-50da-409e-8006-a2441c49fd0b}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"1.0.7.1652906823"
		"\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.e4bdca96fb46d22bc12f5bc5bdb5cdb518555fd1762653f8afc96d06b34ec74b\"}]},\"ping\":{\"ping_freshness\":\"{7c36188a-6de1-4df8-bc52-71b4a7f9a79d}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"852\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl"
		":\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{e67453cf-19f3-48e3-aefd-c1d39d563ddb}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{"
		"\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{921f8563-297c-49c2-94a5-2c8982447d45}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\""
		"ping_freshness\":\"{77499c42-7f65-46e3-9538-e13096aab3c9}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{8f249760-4905-4ed2-8af4-4dc988a5f828}\",\"rd\":6244},\""
		"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:23ml@0.1\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\"}]},\"ping\":{\"ping_freshness\":\"{a3b5387b-7ad4-4703-87d5-c0aec91f80da}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\""
		"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6156,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.74316953175dd4fc990c661551ce1387c462d705f9eff88d759fb130885a3530\"}]},\"ping\":{\"ping_freshness\":\"{0fd34425-638d-4694-a858-260296b10a3e}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2024.2.4.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{ae8b9250-dc17-4dcd-b517-04ff56dbc612}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\""
		"packages\":{\"package\":[{\"fp\":\"1.887c873b6c3a26844482754c8534268fcd848b8c543b652626b4d4ec367f26fd\"}]},\"ping\":{\"ping_freshness\":\"{b681d509-f2fd-4da2-9556-8bfca080764d}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"3017\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\""
		":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.140\",\"protocol\":\"3.1\",\"requestid\":\"{a44d5ed0-bf07-4d74-8f9c-9b33407bb685}\",\"sessionid\":\"{fc9aa2d9-13cb-4807-87de-9262eca857a5}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.372\"},\"updaterversion\":\"121.0.6167.140\"}}", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_concurrent_start(NULL);

	web_url("7.14bd680f6.chunk.js", 
		"URL=https://codesandbox.io/static/js/7.14bd680f6.chunk.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://j17lt.csb.app/", 
		"Snapshot=t61.inf", 
		LAST);

	web_url("1.390d5cd6d.chunk.js", 
		"URL=https://codesandbox.io/static/js/1.390d5cd6d.chunk.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://j17lt.csb.app/", 
		"Snapshot=t62.inf", 
		LAST);

	web_url("2.77529c16f.chunk.js", 
		"URL=https://codesandbox.io/static/js/2.77529c16f.chunk.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://j17lt.csb.app/", 
		"Snapshot=t63.inf", 
		LAST);

	web_url("0.681043136.chunk.js", 
		"URL=https://codesandbox.io/static/js/0.681043136.chunk.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://j17lt.csb.app/", 
		"Snapshot=t64.inf", 
		LAST);

	web_concurrent_end(NULL);

	/* Get  Single User */

	web_add_cookie("_gid=GA1.2.1026438250.1707213281; DOMAIN=reqres.in");

	web_add_cookie("_ga_CESXN06JTW=GS1.1.1707213281.1.0.1707213281.0.0.0; DOMAIN=reqres.in");

	web_add_cookie("_ga=GA1.1.428343557.1707213281; DOMAIN=reqres.in");

	web_add_cookie("_ga_WSM10MMEKC=GS1.2.1707213282.1.0.1707213282.0.0.0; DOMAIN=reqres.in");

	lr_think_time(148);

	web_custom_request("2", 
		"URL=https://reqres.in/api/users/2", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://reqres.in/", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASJwmmDSrmN6FiMRIFDZFhlU4SBQ2RYZVOEgUNlJCS-iHmYtxJlY-mexInCRGeYVDQwopZEgUNkWGVThIFDZFhlU4SBQ2UkJL6IeZi3EmVj6Z7", 
		"URL=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASJwmmDSrmN6FiMRIFDZFhlU4SBQ2RYZVOEgUNlJCS-iHmYtxJlY-mexInCRGeYVDQwopZEgUNkWGVThIFDZFhlU4SBQ2UkJL6IeZi3EmVj6Z7?alt=proto", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t66.inf", 
		LAST);

	web_url("ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASNQksD-n7FCVExhIFDQbtu_8SBQ2RYZVOEgUNkWGVThIFDZFhlU4SBQ2UkJL6IRSfFAmcm5-REjUJfzzqj0LVunISBQ0G7bv_EgUNkWGVThIFDZFhlU4SBQ2RYZVOEgUNlJCS-iEUnxQJnJufkQ==", 
		"URL=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASNQksD-n7FCVExhIFDQbtu_8SBQ2RYZVOEgUNkWGVThIFDZFhlU4SBQ2UkJL6IRSfFAmcm5-REjUJfzzqj0LVunISBQ0G7bv_EgUNkWGVThIFDZFhlU4SBQ2RYZVOEgUNlJCS-iEUnxQJnJufkQ==?alt=proto", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t67.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "0");

	/* Post request */

	lr_think_time(26);

	web_custom_request("users_2", 
		"URL=https://reqres.in/api/users", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://reqres.in/", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"name\":\"morpheus\",\"job\":\"leader\"}", 
		LAST);

	/* Put Update */

	lr_think_time(55);

	web_custom_request("2_2", 
		"URL=https://reqres.in/api/users/2", 
		"Method=PUT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://reqres.in/", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		"Body={\"name\":\"morpheus\",\"job\":\"zion resident\"}", 
		LAST);

	/* Delete */

	lr_think_time(40);

	web_url("monaco-typings-ata.1ade573d.worker.js", 
		"URL=https://codesandbox.io/monaco-typings-ata.1ade573d.worker.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://codesandbox.io/embed/polished-butterfly-j17lt?autoresize=1&fontsize=14&theme=dark&view=preview", 
		"Snapshot=t70.inf", 
		LAST);

	return 0;
}